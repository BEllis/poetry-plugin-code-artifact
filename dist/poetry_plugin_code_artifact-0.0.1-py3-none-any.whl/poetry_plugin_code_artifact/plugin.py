from typing import cast, Callable

from poetry.console.application import Application
from poetry.console.commands.command import Command
from poetry.plugins import ApplicationPlugin
from poetry.repositories.legacy_repository import LegacyRepository

import boto3
from mypy_boto3_codeartifact.client import CodeArtifactClient


class DeferredString(str):

    def __new__(cls, deferred_value: Callable[[], str]):
        instance = super().__new__(cls, "")
        instance.deferred_value = deferred_value
        return instance

    def __str__(self):
        if not isinstance(self.deferred_value, str):
            self.deferred_value = self.deferred_value()

        return self.deferred_value


class PackageInfoApplicationPlugin(
    ApplicationPlugin,
):
    def commands(self) -> list[type[Command]]:
        return []

    def activate(self, application: Application) -> None:
        super(self).activate(application)

        tool_section = application.poetry.pyproject.data.get("tool")
        assert isinstance(tool_section, dict)
        plugin_config_section = tool_section.get("poetry-plugin-code-artifact", {})
        sources = tool_section.get("sources", [])
        for source in sources:
            name = source.get("name", None)
            domain = source.get("aws-code-artifact-domain", None)
            owner = source.get("aws-code-artifact-owner", None)
            region = source.get("aws-code-artifact-region", None)
            repository = source.get("aws-code-artifact-repository", None)

            url = f"https://{domain}-{owner}.d.codeartifact.{region}.amazonaws.com/pypi/{repository}/simple/"
            config = None
            disable_cache = application.poetry.disable_cache

            application.poetry.pool.add_repository(
                LegacyRepository(name, url, config, disable_cache)
            )

            def get_auth_token() -> str:
                client: CodeArtifactClient = boto3.client("codeartifact")
                try:
                    response = client.get_authorization_token(domainOwner=owner,
                                                              domain=domain)
                    return response.get("authorizationToken")
                finally:
                    client.close()

            auth_token = DeferredString(get_auth_token)

            application.poetry.config[f"http-basic.{name}.username"] = "aws"
            application.poetry.config[f"http-basic.{name}.password"] = auth_token

# export POETRY_REPOSITORIES_PUBLISH_URL=$(aws codeartifact get-repository-endpoint --domain-owner 123456789012 --domain example --repository python-local --format pypi --query 'repositoryEndpoint' --output text)

